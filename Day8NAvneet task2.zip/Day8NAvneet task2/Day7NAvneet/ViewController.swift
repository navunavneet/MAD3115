//
//  ViewController.swift
//  Day7NAvneet
//
//  Created by MacStudent on 2018-03-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController {

    @IBOutlet weak var mymap: MKMapView!
    
    
    //let lambtonCollegeLocation = CLLocation(latitude : 43.773257, longitude: -79.34355)
    
    
    
    // portion of distinct we want to show
    let regionRadius: CLLocationAccuracy = 500
    let locationManager = CLLocationManager()
    
    
    
    
override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        mymap.mapType = MKMapType.standard
        
        
       // centerMapOnLocation(Location: LambtonCollegeLocation, title: "Lambton College", subtitle: "256 NorthYork")
    
    locationManager.delegate = self
    locationManager.desiredAccuracy = kCLLocationAccuracyBest
    
    
    locationManager.requestAlwaysAuthorization()
    locationManager.requestWhenInUseAuthorization()
    if (CLLocationManager.locationServicesEnabled()) {
    locationManager.startUpdatingLocation()
    }
    
}

    
    
 override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

//centre map on specific locatiobns
    
    func centerMapOnLocation(Location: CLLocation, title: String, subtitle: String){
    //get location cordinates
    
        let cordinateRegion = MKCoordinateRegionMakeWithDistance(Location.coordinate,regionRadius,regionRadius)
    
    //focus the map on specific location
        mymap.setRegion(cordinateRegion,animated: true)
    
    
    //drop a pin at user's current location
    let myAnnotation: MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(Location.coordinate.latitude, Location.coordinate.longitude);
    
    myAnnotation.title = title
        myAnnotation.subtitle = subtitle
    
    //  display pin on loacation
    
        mymap.addAnnotation(myAnnotation)
    
    
    }
}


extension ViewController:
CLLocationManagerDelegate{


func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
    print("error:: \(error.localizedDescription)")

}



func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
    if status == .authorizedWhenInUse {
        locationManager.requestLocation()
        
}
}
    func locationManager(_ mangaer:
    CLLocationManager, didUpdateLocations locations: [CLLocation]) {

    if locations.first != nil {
        print("location:: \(locations)")
}

        centerMapOnLocation(Location: locationManager.location!, title: "Current Location", subtitle: " 47th")
}
}

